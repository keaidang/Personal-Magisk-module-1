#!/system/bin/sh

# Runs when module is removed.

exit 0