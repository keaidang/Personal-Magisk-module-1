# Auto MV Magisk Module Scaffold

## Behavior

- Background watcher checks `/storage/emulated/0/DCIM/Camera/` every 3 seconds.
- Files with names starting with `VID` are moved to `/storage/emulated/0/Music/`.
- If filename ends with `.mp4` or `.MP4`, the extension is removed during move.
- File size must be stable for 2 seconds before moving to avoid half-written files.

## Structure

- module.prop
- customize.sh
- post-fs-data.sh
- service.sh
- uninstall.sh
- action.sh
- system.prop
- sepolicy.rule
- common/
- system/
- META-INF/com/google/android/

## Quick Test

- Install zip from Magisk.
- Reboot.
- Put a new file like `VID_demo.mp4` into `DCIM/Camera`.
- Check `/storage/emulated/0/Music/VID_demo`.

## Package

Compress files in this directory into a zip, then install from Magisk app.
