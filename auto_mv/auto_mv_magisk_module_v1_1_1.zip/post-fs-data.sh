#!/system/bin/sh
MODDIR=${0%/*}

# Runs in early boot stage.
# Put early-init logic here.

exit 0